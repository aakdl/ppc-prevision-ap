import React from "react";

export default function Activities() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Atividades da Semana</h1>
      <p>Lista de atividades previstas será exibida aqui...</p>
    </div>
  );
}