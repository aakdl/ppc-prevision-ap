import React from "react";

export default function Dashboard() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Dashboard PPC</h1>
      <p>Resumo e métricas vão aparecer aqui...</p>
    </div>
  );
}